/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maveninventory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hetpa
 */
public class InventoryDAO {
    private static final Logger LOGGER = Logger.getLogger(InventoryDAO.class.getName());
    private final Connection conn;

    public InventoryDAO() {
        this.conn = DatabaseConnection.getConnection();
    }

    // CREATE (Add new item)
    public void addItem(InventoryItem item) {
        String query = "INSERT INTO inventory (item_name, quantity, price, category, supplier) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, item.getItemName());
            stmt.setInt(2, item.getQuantity());
            stmt.setDouble(3, item.getPrice());
            stmt.setString(4, item.getCategory());
            stmt.setString(5, item.getSupplier());
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error adding item to inventory", e);
        }
    }

     // READ (Get all items)
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> itemList = new ArrayList<>();
        String query = "SELECT * FROM inventory";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                InventoryItem item = new InventoryItem(
                        rs.getInt("id"),
                        rs.getString("item_name"),
                        rs.getInt("quantity"),
                        rs.getDouble("price"),
                        rs.getString("category"),
                        rs.getString("supplier")
                );
                itemList.add(item);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error fetching inventory items", e);
        }
        return itemList;
    }

     // UPDATE (Modify item)
     // Method to update an existing item in the database
    // UPDATE (Modify item)
public void updateItem(InventoryItem item) {
    String sql = "UPDATE inventory SET item_name = ?, quantity = ?, price = ?, category = ?, supplier = ?, created_at = ? WHERE id = ?";
    try (PreparedStatement stmt = conn.prepareStatement(sql)) {

        // Validate ID
        if (item.getId() <= 0) {
            LOGGER.log(Level.SEVERE, "Invalid item ID: {0}", item.getId());
            return;
        }

        // Log the SQL query for debugging
        LOGGER.log(Level.INFO, "Executing query: {0}", sql);
        
        LOGGER.log(Level.INFO, "Executing SQL: {0} with item_name={1}, quantity={2}, price={3}, category={4}, supplier={5}, created_at={6}, id={7}",
        new Object[]{sql, item.getItemName(), item.getQuantity(), item.getPrice(), item.getCategory(), item.getSupplier(), new Timestamp(System.currentTimeMillis()), item.getId()});


        // Set parameters for the query from the InventoryItem object
        stmt.setString(1, item.getItemName());
        stmt.setInt(2, item.getQuantity());
        stmt.setDouble(3, item.getPrice());
        stmt.setString(4, item.getCategory());
        stmt.setString(5, item.getSupplier());
        stmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));  // Assuming you want the current timestamp for created_at
        stmt.setInt(7, item.getId());  // Use the ID of the item to update the correct record

        int rowsAffected = stmt.executeUpdate(); // Executes the update query

        if (rowsAffected == 0) {
            LOGGER.log(Level.WARNING, "No rows updated for item with ID: {0}", item.getId());
        } else {
            LOGGER.log(Level.INFO, "Successfully updated item with ID: {0}", item.getId());
        }
    } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Error updating item with ID: " + item.getId(), e);
    }
}



     // DELETE (Remove item)
   public void deleteItem(int itemId) {
    try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM inventory WHERE id = ?")) {
        stmt.setInt(1, itemId);
        stmt.executeUpdate();  // Perform the deletion
    } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Error deleting item by ID", e);
    }
}


    
    public InventoryItem getItemById(int id) {
    String query = "SELECT * FROM inventory WHERE id = ?";
    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        
        if (rs.next()) {
            return new InventoryItem(
                rs.getInt("id"),
                rs.getString("item_name"),
                rs.getInt("quantity"),
                rs.getDouble("price"),
                rs.getString("category"),
                rs.getString("supplier")
            );
        }
    } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Error fetching item by ID", e);
    }
            return null; // Return null if item not found
    }

}
