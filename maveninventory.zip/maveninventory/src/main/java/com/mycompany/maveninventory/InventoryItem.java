/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maveninventory;

/**
 *
 * @author hetpa
 */
public class InventoryItem {
    private int id;
    private String itemName;
    private int quantity;
    private double price;
    private String category;
    private String supplier;

    // Constructor without ID (For Adding New Items)
    public InventoryItem(String itemName, int quantity, double price, String category, String supplier) {
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.category = category;
        this.supplier = supplier;
    }

    // Constructor with ID (For Fetching Items from Database)
    public InventoryItem(int id, String itemName, int quantity, double price, String category, String supplier) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.category = category;
        this.supplier = supplier;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    // toString() Method for Easy Debugging
    @Override
    public String toString() {
        return "InventoryItem{" +
                "id=" + id +
                ", itemName='" + itemName + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                ", category='" + category + '\'' +
                ", supplier='" + supplier + '\'' +
                '}';
    }
}
